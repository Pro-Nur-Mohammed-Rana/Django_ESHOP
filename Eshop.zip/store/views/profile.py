from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.views import View
from store.models.customer import Customer

# Create your views here.
class customerProfile(View):

    def get(self, request):

        customer = request.session.get('customer')
        info = Customer.get_customer_by_email(customer)
        print(info)
        return render(request, 'profile.html', {'info': info})